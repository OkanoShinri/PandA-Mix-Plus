# PandA-Mix-Plus

[https://addons.mozilla.org/ja/firefox/addon/panda-mix-plus/](https://addons.mozilla.org/ja/firefox/addon/panda-mix-plus/)

PandAを時間割のように表示したりするアドオン  
由来は時間割が多段タブのように見えることから

![スクリーンショット 2022-04-15 232028](https://user-images.githubusercontent.com/72956592/163585160-879be15c-4064-4794-bc73-9505841f853a.png)

## Chrome(またはChromiumベースのブラウザ)ユーザーの方へ

開発者がChromeストアの登録料5ドルを出し渋っているため、Chromeストアでは公開されていません。なので、手動でインストールしていただく必要があります。

1. このページ右上の緑色の`Code`をクリックし、`Download ZIP`をクリック
2. ダウンロードしたファイルを解凍する
3. Chromeを起動し、右上の3つの点のメニュー>その他の設定>拡張機能
4. 右上の「デベロッパーモード」をONにする
5. 左上の「パッケージ化されていない拡張機能を読み込む」をクリック
6. さっき解凍したフォルダを選択する
