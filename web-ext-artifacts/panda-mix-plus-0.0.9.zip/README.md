# PandA-Mix-Plus

PandAを時間割のように表示したりするアドオン  
由来は時間割が多段タブのように見えることから

![image](https://user-images.githubusercontent.com/72956592/164980037-8b326fe1-8776-4355-b147-efb717e236e0.png)

## Firefoxユーザーの方

[https://addons.mozilla.org/ja/firefox/addon/panda-mix-plus/](https://addons.mozilla.org/ja/firefox/addon/panda-mix-plus/)から入れてください。

## Chrome(またはChromiumベースのブラウザ)ユーザーの方

開発者がChromeストアの登録料5ドルを出し渋っているため、Chromeストアでは公開されていません。なので、手動でインストールしていただく必要があります。

1. このページ右上の緑色の`Code`をクリックし、`Download ZIP`をクリック
2. ダウンロードしたファイルを解凍する
3. Chromeを起動し、右上の3つの点のメニュー>その他の設定>拡張機能（他のブラウザでも拡張機能ページがどこかにあるはずです）
4. 右上の「デベロッパーモード」をONにする
5. 左上の「パッケージ化されていない拡張機能を読み込む」をクリック
6. さっき解凍したフォルダの中の、`chrome`フォルダを選択する
