# PandA-Mix-Plus

[https://addons.mozilla.org/ja/firefox/addon/panda-mix-plus/](https://addons.mozilla.org/ja/firefox/addon/panda-mix-plus/)

PandAを時間割のように表示したりするアドオン  
由来は時間割が多段タブのように見えることから

![image](https://user-images.githubusercontent.com/72956592/163681707-00391701-e521-433a-8857-1a58c83e894a.png)

## Chrome(またはChromiumベースのブラウザ)ユーザーの方へ

開発者がChromeストアの登録料5ドルを出し渋っているため、Chromeストアでは公開されていません。なので、手動でインストールしていただく必要があります。

1. このページ右上の緑色の`Code`をクリックし、`Download ZIP`をクリック
2. ダウンロードしたファイルを解凍する
3. Chromeを起動し、右上の3つの点のメニュー>その他の設定>拡張機能（他のブラウザでも拡張機能ページがどこかにあるはずです）
4. 右上の「デベロッパーモード」をONにする
5. 左上の「パッケージ化されていない拡張機能を読み込む」をクリック
6. さっき解凍したフォルダの中の、`chrome`フォルダを選択する
